# 🗂 Duplicate File Cleaner with Python  

Tired of backups taking double the space?  
This script helps you **find and move duplicate files** into a separate folder, saving 30–40% of your storage.  

---

## 🚀 How it works  
1. Scans all files in the given folder.  
2. Creates a **SHA-256 hash** (unique fingerprint) for each file.  
3. Detects duplicates (same hash).  
4. Moves duplicates into a new folder `Duplicates/`.  

---

## 📦 Requirements  

- Python 3.x  
- No extra libraries needed (uses only `os`, `hashlib`, `shutil`).  

---

## ▶️ Usage  

```bash
# Clone this repo
git clone https://github.com/YOUR_USERNAME/duplicate-cleaner.git
cd duplicate-cleaner

# Step 1: Create sample backup folder with duplicates
python create_sample_backup.py

# Step 2: Run script to clean duplicates
python remove_duplicates.py
```

---

## 🧪 Example  

### Before Running:
```
sample_backup/
├── Photos/
│   ├── IMG_20250101.txt
│   ├── IMG-20250101-WA0001.txt
│   ├── IMG_20250102.txt
│   ├── IMG_20250102 (1).txt
├── Documents/
│   ├── Report.txt
│   ├── Report (1).txt
├── Videos/
│   ├── Meeting.txt
│   ├── Meeting (copy).txt
```

### After Running:
```
sample_backup/
├── Photos/
│   ├── IMG_20250101.txt
│   ├── IMG_20250102.txt
├── Documents/
│   ├── Report.txt
├── Videos/
│   ├── Meeting.txt

Duplicates/
├── IMG-20250101-WA0001.txt
├── IMG_20250102 (1).txt
├── Report (1).txt
├── Meeting (copy).txt
```

✅ Duplicate files moved to `Duplicates/`  
✅ Saves storage space  
